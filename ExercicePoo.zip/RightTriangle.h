//
// Created by Martin Pouliot on 2018-10-23.
//

#ifndef EXAMPLEPOO_RIGHTTRIANGLE_H
#define EXAMPLEPOO_RIGHTTRIANGLE_H


#include "Triangle.h"

class RightTriangle: public Triangle {
public:
    RightTriangle(Point pt1,Point pt2, Point pt3);
};


#endif //EXAMPLEPOO_RIGHTTRIANGLE_H
